﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace pr16_3_mar
{
    class Program
    {
        static void Main(string[] args)
        {
            if (File.Exists("file1.txt"))
            {
                try
                {
                    string[] m1 = File.ReadAllText("file1.txt").Split(' ', (char)StringSplitOptions.RemoveEmptyEntries);
                    double[] m2 = m1.Select(double.Parse).ToArray();
                    var ch = m2.GroupBy(n => n).Select(k => new { numb = k.Key, p = k.Count() });
                    Console.WriteLine("Число\tЧастота");
                    foreach (var n in ch)
                    {
                        Console.WriteLine($"{n.numb}\t{n.p}");
                    }
                    var m = m2.Select(k => k * ch.First(x => x.numb == k).p).ToArray().GroupBy(k => k).Select(k => new { numb = k.Key, p = k.Count() });
                    if (File.Exists("file2.txt"))
                    {
                        File.WriteAllLines("file2.txt", m.Select(y => y.ToString()));
                    }
                    else Console.WriteLine("Файл не найден");
                    Console.WriteLine("--------------");
                    foreach (var k in m)
                    {
                        Console.WriteLine($"{k.numb}-{k.p}");
                    }
                }
                catch
                {
                    Console.WriteLine("Введите данные корректно");
                }

            }
            else Console.WriteLine("Файл не найден");
            Console.ReadLine();
        }
    }
}
