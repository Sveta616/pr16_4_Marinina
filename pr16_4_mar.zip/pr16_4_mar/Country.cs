﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr16_4_mar
{
    class Country
    {
        public string Name
            {
            get;
            set;
            }
        public long People
        {
            get;
            set;
        }
        public Country(string name, long people)
        {
            Name = name;
            People = people;
        }
    }
}
