﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace pr16_4_mar
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        List <Country> countries=new List<Country>();
        List<Country> countries2 = new List<Country>();

        private void FindPeople(object sender, EventArgs e)
        {
            if (File.Exists("file.txt"))
            {
                
                string[] text = File.ReadAllLines("file.txt");
                if (text.Length != 1)
                {
                    foreach (string t in text)
                    {
                        char a = t.First(c => char.IsDigit(c));
                        int b = t.IndexOf(a);
                        string name = t.Substring(0, b);
                        string pep = t.Substring(b);
                        long people = long.Parse(pep.Replace(" ", ""));
                        countries.Add(new Country(name, people));
                    }

                    if (int.TryParse(textBox1.Text.Replace(" ", ""), out int rez))
                    {
                        long k = long.Parse(textBox1.Text.Replace(" ", ""));
                        if (k > 0)
                        {
                            var sort= countries.Where(c => c.People > k) .OrderBy(c => c.Name.Length).ToList();

                            listBox1.Items.Clear();
                            foreach (Country s in sort)
                            {
                                listBox1.Items.Add(s.Name + " " + s.People);
                            }
                        }
                        else MessageBox.Show("Численность населения должна быть больше нуля");
                    }
                    else MessageBox.Show("Введите данные корректно");
                }
                else MessageBox.Show("Файл пустой, занесите данные пожалуйста");
            }
            else MessageBox.Show("Файл не найден");

        }

        private void Form1_Load(object sender, EventArgs e)
        {
        
        }

        private void SortofLength(object sender, EventArgs e)
        {
            if (File.Exists("file.txt"))
            {
                string[] text = File.ReadAllLines("file.txt");
                if (text.Length != 1)
                {
                    foreach (string t in text)
                    {
                        char a = t.First(c => char.IsDigit(c));
                        int b = t.IndexOf(a);
                        string name = t.Substring(0, b);
                        string pep = t.Substring(b);
                        long people = long.Parse(pep.Replace(" ", ""));
                        countries2.Add(new Country(name, people));
                    }
                    var sort = countries2.OrderBy(c => c.Name.Length).ThenBy(c=>c.Name).ToList();
                    listBox2.Items.Clear();
                    foreach (Country c in sort)
                    {
                        listBox2.Items.Add(c.Name + " " + c.People);
                    }
                }
                else MessageBox.Show("Ваш файл пустой, введите данные пожалуйста");

            }
            else MessageBox.Show("Файл не найден, убедитесь в его существовании");
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
